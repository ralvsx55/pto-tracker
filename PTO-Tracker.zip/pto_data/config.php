<?php
declare(strict_types=1);
// Local config written by tools/dev_reset.php. See pto_app/config.example.php for the keys.
return array (
  'db' => 
  array (
    'host' => '127.0.0.1',
    'name' => 'pto_local',
    'user' => 'root',
    'pass' => '',
  ),
  'base_url' => 'http://127.0.0.1:8020/',
  'environment' => 'local',
  'secret' => '87f686ce66741700ffdfd306b92f85fcc44caa3c5c676ae02ac3beea75da9dae',
  'install_token' => '5ae94bb3e10d6b58a7c5504704b6c43a',
  'alert_email' => 'chris@lightsaberpromotions.com',
  'alert_from' => 'pto@lightsaberpromotions.com',
);
